package com.example.day19

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
